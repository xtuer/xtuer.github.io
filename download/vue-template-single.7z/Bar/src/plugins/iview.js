import 'iview/dist/styles/iview.css';
import Vue from 'vue';
import iView from 'iview';

Vue.use(iView);
