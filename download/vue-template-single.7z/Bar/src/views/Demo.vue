<template>
    <div class="demo">
        <div class="progress">
            <div class="first" :style="{ width: progress.first + '%' }"/>
            <div class="second" :style="{ width: progress.second + '%' }"/>
        </div>
    </div>
</template>

<script>
export default {
    props: {},
    data() {
        return {
            progress: {
                first: 27,
                second: 45,
            },
        };
    },
};
</script>

<style lang="scss">
.demo {
    padding: 50px;

    .progress {
        display: flex;
        width: 300px;
        height: 24px;
        overflow: hidden;
        border-radius: 20px;
        background: #e8eaec;

        .first {
            height: 100%;
            background: #2db7f5;
            border-radius: 20px 0 0 20px;
        }

        .second {
            height: 100%;
            background: #808695;
            border-radius: 0 20px 20px 0;
        }
    }
}
</style>
