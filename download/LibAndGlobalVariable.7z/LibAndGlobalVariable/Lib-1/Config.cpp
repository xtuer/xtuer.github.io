#include "Config.h"

int Config::count = 0;

Config::Config() {

}


Config::~Config() {

}

int g = 0;
